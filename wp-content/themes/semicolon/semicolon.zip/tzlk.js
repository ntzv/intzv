var tip = '1';
var isp = '';	
var napr = '';
var gab = '';
var klim_kat = '';
var per_t = '';	
var maxtok = '';
var mintok = '';
var tokterm = '';
var tokstand = '';
var tokper = '';
var perek = '';
var perekl = false;
var tok_perek = '';	
var tokperterm = '';	
var tokperstand = '';
var bar = '';
var max_vyv = 0;
var obm = new Array();	
var vyv = 2;	
var otp = false;
obm[0] = 0;	
// 333 - 180 = 153	
$ = window.jQuery;	
//$(document).ready(function(){
//	
//});
t = document.getElementById('tip');

tip = t.options[t.selectedIndex].value;

$('#klass').html('<p>'+t.options[t.selectedIndex].text+'</p>');
$.ajax({
      type: "POST",
      url: "/wp-content/themes/semicolon/res2sel.php",
      //data: "table="+ encodeURIComponent("analogs") + '&column0='+ encodeURIComponent("*") + '&case='+ encodeURIComponent("zavodeq'СЭЩ'"),
      data: "table=tip_ispoln&column0=id&column1=ispoln&case=tip_id_eq_"+tip+"_and_napr_eq_"+1,
      success: function(data1){
		seldata = '<option value="">...</option>';
        $("#gab").html(seldata+data1);
		//$("#bar_v").html('');
      }
    });

  $('#tip').change(function(){	
	tip = this.options[this.selectedIndex].value; 
/*	if (tip == 1 || tip == 2 || tip == 3) {
		$("#tol").css("display", "block"); $("#a00").css("display", "block");
		$("#nali").css("display", "none"); $("#b00").css("display", "none");
		$("#znol").css("display", "none"); $("#c00").css("display", "none");
	}
	if (tip == 4) {
		$("#tol").css("display", "none"); $("#a00").css("display", "none");
		$("#nali").css("display", "block"); $("#b00").css("display", "block");
		$("#znol").css("display", "none"); $("#c00").css("display", "none");
	}
	if (tip == 5) {
		$("#tol").css("display", "none"); $("#a00").css("display", "none");
		$("#nali").css("display", "none"); $("#b00").css("display", "none");
		$("#znol").css("display", "block"); $("#c00").css("display", "block");
	}
*/	seldata = '<option value="">...</option>';
    $.ajax({
      type: "POST",
      url: "/wp-content/themes/semicolon/res2sel.php",
      //data: "table="+ encodeURIComponent("analogs") + '&column0='+ encodeURIComponent("*") + '&case='+ encodeURIComponent("zavodeq'СЭЩ'"),
      data: "table=tip_ispoln&column0=napr&case=tip_id_eq_"+tip,
      success: function(data){
		seldata = '<option value="">0.66</option>';
        $("#napr").html(seldata);
		seldata = '<option value="">...</option>';
		//$("#bar_v").html('');
      }
    });
    $.ajax({
      type: "POST",
      url: "/wp-content/themes/semicolon/res2sel.php",
      //data: "table="+ encodeURIComponent("analogs") + '&column0='+ encodeURIComponent("*") + '&case='+ encodeURIComponent("zavodeq'СЭЩ'"),
      data: "table=tip_obm&column0=klass",
      success: function(data18){
        $("#vtor_b_1").html(seldata+data18);
      }
    });
    $.ajax({
      type: "POST",
      url: "/wp-content/themes/semicolon/res2sel.php",
      //data: "table="+ encodeURIComponent("analogs") + '&column0='+ encodeURIComponent("*") + '&case='+ encodeURIComponent("zavodeq'СЭЩ'"),
      data: "table=kratn&column0=kratn",
      success: function(data19){
        $("#d_vtor_c_1").html(seldata+data19);
      }
    });
    $.ajax({
      type: "POST",
      url: "/wp-content/themes/semicolon/res2sel.php",
      //data: "table="+ encodeURIComponent("analogs") + '&column0='+ encodeURIComponent("*") + '&case='+ encodeURIComponent("zavodeq'СЭЩ'"),
      data: "table=tip_ispoln&column0=id&column1=ispoln&case=tip_id_eq_"+tip+"_and_napr_eq_"+1,
      success: function(data1){
		seldata = '<option value="">...</option>';
        $("#gab").html(seldata+data1);
		$("#bar_v").html('');
      }
    });
  return false;
  });

  $('#napr').change(function(){	
	napr = this.options[this.selectedIndex].text; 
	seldata = '<option value="">...</option>';
	//alert(1);
	t = document.getElementById('tip');
	//alert(t);
	tip = t.options[t.selectedIndex].value;
    $.ajax({
      type: "POST",
      url: "/wp-content/themes/semicolon/res2sel.php",
      //data: "table="+ encodeURIComponent("analogs") + '&column0='+ encodeURIComponent("*") + '&case='+ encodeURIComponent("zavodeq'СЭЩ'"),
      data: "table=tip_ispoln&column0=id&column1=ispoln&case=tip_id_eq_"+tip+"_and_napr_eq_"+napr,
      success: function(data1){
        $("#gab").html(seldata+data1);
		$("#bar_v").html('');
      }
    });
	$.ajax({
      type: "POST",
      url: "/wp-content/themes/semicolon/res2sel.php",
      //data: "table="+ encodeURIComponent("analogs") + '&column0='+ encodeURIComponent("*") + '&case='+ encodeURIComponent("zavodeq'СЭЩ'"),
      data: "table=tip_obm&column0=klass",
      success: function(data18){
        $("#vtor_b_1").html(seldata+data18);
      }
    });
    $.ajax({
      type: "POST",
      url: "/wp-content/themes/semicolon/res2sel.php",
      //data: "table="+ encodeURIComponent("analogs") + '&column0='+ encodeURIComponent("*") + '&case='+ encodeURIComponent("zavodeq'СЭЩ'"),
      data: "table=kratn&column0=kratn",
      success: function(data19){
        $("#d_vtor_c_1").html(seldata+data19);
      }
    });
  
  return false;
  });	

  $('#vtor_v_1').change(function(){	
	v_1 = this.options[this.selectedIndex].text; 
	seldata = '<option value="">...</option>';
    $.ajax({
      type: "POST",
      url: "/wp-content/themes/semicolon/res2sel.php",
      //data: "table="+ encodeURIComponent("analogs") + '&column0='+ encodeURIComponent("*") + '&case='+ encodeURIComponent("zavodeq'СЭЩ'"),
      data: "table=nagruz&column0=nagr&case=vtor_t_eq_"+v_1,
      success: function(data20){
        $("#d_vtor_a_1").html(seldata+data20);
      }
    });
  return false;
  });	
	
  $('#gab').change(function(){	
	gab = this.options[this.selectedIndex].text; 
	isp = this.options[this.selectedIndex].value; 
	seldata = '<option value="">...</option>';
    $.ajax({
      type: "POST",
      url: "/wp-content/themes/semicolon/res2sel.php",
      //data: "table="+ encodeURIComponent("analogs") + '&column0='+ encodeURIComponent("*") + '&case='+ encodeURIComponent("zavodeq'СЭЩ'"),
      data: "table=klimkatref&column0=klim_kat&case=tip_isp_id_eq_"+isp,
      success: function(data2){
        $("#klim_kat").html(seldata+data2);
		$.ajax({
	      type: "POST",
	      url: "/wp-content/themes/semicolon/res2rad.php",
	      data: "table=sectermref&column0=sec_term_id&column1=sec_term&case=tip_isp_id_eq_"+isp,
	      success: function(data15){
			$("#var_v_v").html(data15);
	    //    $("#var_v_v").html('<input id="var_vv" type="text" value="'+data15+'" />');
		//	var_v_1=document.getElementById("var_vv").value;
		//	//alert("2="+mintok);
			$.ajax({
		      type: "POST",
		      url: "/wp-content/themes/semicolon/res2var.php",
		      data: "table=tip_ispoln&column0=opc_bar&case=id_eq_"+isp,
		      success: function(data16){
				//alert("2="+maxtok);
		        $("#bar").html('<input id="bar_" type="text" value="'+data16+'" />');
				bar=document.getElementById("bar_").value;  
				if (bar == 1) {$("#bar_v").html('<input id="bar_vv" type="checkbox" /> - Барьеры');}
				else {$("#bar_v").html('');}
				$("#sec_term_id_sec_term_1").click(function(){ if ($(this).is(':checked')){$("#gib_v").css("display", "none")} });	  
				$("#sec_term_id_sec_term_2").click(function(){ if ($(this).is(':checked')){$("#gib_v").css("display", "none")} });	  
				$("#sec_term_id_sec_term_3").click(function(){ if ($(this).is(':checked')){$("#gib_v").css("display", "inline-block")} else {$("#gib_v").css("display", "none")} });	  
				$("#sec_term_id_sec_term_4").click(function(){ if ($(this).is(':checked')){$("#gib_v").css("display", "inline-block")} else {$("#gib_v").css("display", "none")} });	  
		      }
		    });  
	      }
	    });  
        //$("#var_v_1").prop('disabled', true);
      }
    });
	$.ajax({
      type: "POST",
      url: "/wp-content/themes/semicolon/res2var.php",
      data: "table=tip_ispoln&column0=max_tok&case=id_eq_"+isp,
      success: function(data3){
		$("#max_t").html('<input id="max_tok" type="text" value="'+data3+'" />');
		maxtok=document.getElementById("max_tok").value;
		//alert("1="+maxtok);
		$.ajax({
	      type: "POST",
	      url: "/wp-content/themes/semicolon/res2var.php",
	      data: "table=tip_ispoln&column0=min_tok&case=id_eq_"+isp,
	      success: function(data4){
	        $("#min_t").html('<input id="min_tok" type="text" value="'+data4+'" />');
			mintok=document.getElementById("min_tok").value;
			//alert("2="+mintok);
			$.ajax({
		      type: "POST",
		      url: "/wp-content/themes/semicolon/res2sel.php",
		      data: "table=tip_ispoln&column0=isp_vyv&case=id_eq_"+isp,
		      success: function(data5){
				//alert(data5);
				$("#koeftr").html('');
				if (isp == 113) {data25 = data5 + '<option value="">470/1</option>';}
				else {data25 = data5;}
		        $("#koeftr").html(seldata+data25);
		        
				$.ajax({
		      	  type: "POST",
		     	  url: "/wp-content/themes/semicolon/res2var.php",
		      	  data: "table=tip_ispoln&column0=max_vyv&case=id_eq_"+isp,
		      	  success: function(data17){
				  //alert("2="+maxtok);
		        	$("#max_vyv").html('<input id="max_v" type="text" value="'+data17+'" />');
					max_vyv=document.getElementById("max_v").value;
					//alert(max_vyv);
		      	  }
		   	    });  
		      }
		    });  
	      }
	    });  
      }
    });  
  return false;
  });	
	
  $('#per_t').change(function(){	
	per_t = this.options[this.selectedIndex].text; 
	seldata = '<option value="">...</option>';
	$.ajax({
	  type: "POST",
	  url: "/wp-content/themes/semicolon/res2var.php",
	  data: "table=tok_term&column0=max&case=tok_eq_"+per_t,
	  success: function(data8){
	    $("#tok_term").html('<input id="t_term" type="text" value="'+data8+'" />');
	    tokterm=document.getElementById("t_term").value;
		//alert("2="+mintok);
		$.ajax({
		  type: "POST",
		  url: "/wp-content/themes/semicolon/res2var.php",
		  data: "table=tok_term&column0=stand&case=tok_eq_"+per_t,
		  success: function(data9){
		    //alert("2="+maxtok);
		    $("#tok_stand").html('<input id="t_stand" type="text" value="'+data9+'" />');
			tokstand=document.getElementById("t_stand").value;  

			//значение первичного тока вторичной обмотки, равное per_t
			$.ajax({
		      type: "POST",
		      url: "/wp-content/themes/semicolon/res2sel.php",
		      data: "table=per_t&column0=tok&case=tok_lteq_"+maxtok+"_and_tok_gteq_"+mintok+"&mark="+per_t+"",
		      success: function(data21){
                $("#vtor_p_1").html(seldata+data21);
			  }
			});	
			  
			$.ajax({
		      type: "POST",
		      url: "/wp-content/themes/semicolon/res2sel.php",
		      data: "table=tokterm&column0=tokterm&case=tokterm_lteq_"+tokterm+"&mark="+tokstand+"",
		      success: function(data7){
		        //alert("stand="+tokstand);
		        $("#term_t").html(seldata+data7);
//------------------для тока переключения-----------------
				  $.ajax({
					type: "POST",
					url: "/wp-content/themes/semicolon/res2var.php",
					data: "table=tip_ispoln&column0=opc_perek&case=id_eq_"+isp,
					success: function(data10){
	                  $("#tok_per").html('<input id="t_perek" type="text" value="'+data10+'" />');
			          tokper=document.getElementById("t_perek").value;
			          //alert("2="+mintok);
			          $.ajax({
		                type: "POST",
		                url: "/wp-content/themes/semicolon/res2var.php",
		                data: "table=per_t&column0=perek&case=tok_eq_"+per_t,
		                success: function(data11){
				          //alert("2="+maxtok);
		                  $("#per").html('<input id="_perek" type="text" value="'+data11+'" />');
			              perek=document.getElementById("_perek").value;
						  tok_perek = per_t / 2;	
						  $("#perpert1").html('Номинальный ток<br /> переключения, А<br /><input id="tokperek" type="text" class="inputbox" style="width:100px; background:#fee;" value="'+tok_perek+'" disabled />');
						  $("#perpert2").html('Ток термической стойкости<br /> переключения, кА<br /><select id="per_term" class="inputbox1"></select>');
						  $('#perek').click(function(){ if ($(this).is(':checked') && (!otp)){$("#perpert1").css("display", "inline-block"); $("#perpert2").css("display", "inline-block"); perekl = true;} else {$("#perpert1").css("display", "none"); $("#perpert2").css("display", "none"); perekl = false;} });	
						  //alert(per_t); $("#perpert").html('<input type="checkbox" id="perek" value="" /> - Переключение по<br /> первичному току');	
						  if ((perek * tokper * 1 == 1) && (!otp)) {
							  $('#perek').prop('disabled', false); //$("#perpert").css("display", "inline-block"); 
						  } else {$('#perek').prop('disabled', true);$("#perpert1").css("display", "none"); $("#perpert2").css("display", "none");};	
			              $.ajax({
		                    type: "POST",
		                    url: "/wp-content/themes/semicolon/res2var.php",
		                    data: "table=tok_term&column0=max&case=tok_eq_"+tok_perek,
		                    success: function(data12){
				              //alert("2="+maxtok);
		                      $("#tokper_term").html('<input id="tper_term" type="text" value="'+data12+'" />');
	                          tokperterm=document.getElementById("tper_term").value;
			                  $.ajax({
		                        type: "POST",
		                        url: "/wp-content/themes/semicolon/res2var.php",
		                        data: "table=tok_term&column0=stand&case=tok_eq_"+tok_perek,
		                        success: function(data13){
				                  //alert("2="+maxtok);
		                          $("#tokper_stand").html('<input id="tper_stand" type="text" value="'+data13+'" />');
	                              tokperstand=document.getElementById("tper_stand").value;
			                      $.ajax({
		                            type: "POST",
		                            url: "/wp-content/themes/semicolon/res2sel.php",
		                            data: "table=tokterm&column0=tokterm&case=tokterm_lteq_"+tokperterm+"&mark="+tokperstand,
		                            success: function(data14){
				                      //alert("2="+maxtok);
		                              $("#per_term").html(seldata+data14);
		                            }
		                          });  
		                        }
		                      });  
		                    }
		                  });  
		                }
		              });  
	                }
	              }); 
//------------------------------------------------------------------				  
		      }
		    });  
		  }
		});  
	  }
	});  
	  
    $.ajax({
      type: "POST",
      url: "/wp-content/themes/semicolon/res2var.php",
      //data: "table="+ encodeURIComponent("analogs") + '&column0='+ encodeURIComponent("*") + '&case='+ encodeURIComponent("zavodeq'СЭЩ'"),
      data: "table=tip_ispoln&column0=term_sek&case=id_eq_"+isp,
      success: function(data6){
        $("#vrem_pr").html('<input id="vrem_prot" class="inputbox" style="width:100px; background:#fee;" type="text" value="'+data6+'" disabled />');
      }
    });
  return false;
  });	

var rowinner1 = '';
var rowinner2 = '';	
	function addrow(t){
		tab = document.getElementById(t);
		var rowCount = tab.rows.length;
		var row = tab.insertRow(rowCount-1);
		if (rowinner1 == '') {rowinner = tab.rows[2].innerHTML; rowinner1 = tab.rows[2].innerHTML;}
		else {rowinner = rowinner1};
        rowinner = rowinner.replace('<td id="tdd_0"><p>1</p></td>', '<td id="tdd_'+(rowCount-3)+'"><p>' + (rowCount-2) + '</p></td>');
        rowinner = rowinner.replace('input id="vyv_1_0"', 'input id="vyv_' + (rowCount-2) + '_0"');
		rowinner = rowinner.replace('table id="a01"', 'table id="a0' + (rowCount-2) + '"');
		rowinner = rowinner.replace('onclick="addrow2(\'a01\');"', 'onclick="addrow2(\'a0' + (rowCount-2) + '\');"');
		rowinner = rowinner.replace('id="td_1"',        'id="td_'        + (rowCount-2) + '"');
		rowinner = rowinner.replace('id="vtor_p_1"',    'id="vtor_p_'    + (rowCount-2) + '"');
		rowinner = rowinner.replace('id="vtor_v_1"',    'id="vtor_v_'    + (rowCount-2) + '"');
		rowinner = rowinner.replace('id="id_vtor_a_1"', 'id="id_vtor_a_' + (rowCount-2) + '"');
		rowinner = rowinner.replace('id="d_vtor_a_1"',  'id="d_vtor_a_'  + (rowCount-2) + '"');
		rowinner = rowinner.replace('id="vtor_b_1"',    'id="vtor_b_'    + (rowCount-2) + '"');
		rowinner = rowinner.replace('id="id_vtor_c_1"', 'id="id_vtor_c_' + (rowCount-2) + '"');
		rowinner = rowinner.replace('id="d_vtor_c_1"',  'id="d_vtor_c_'  + (rowCount-2) + '"');
		obm.push(0);
		vyv = vyv + 2;
		row.innerHTML = rowinner;
//		row.innerHTML = '<td><p>' + (rowCount-2) + '</p></td><td colspan="7"><table id="a0' + (rowCount-2) + '"><tr><td></td><td><p>И1-И2</p></td><td><select id="vtor_p_1" class="inputbox1"></select></td><td><select id="vtor_v_1" class="inputbox1"></select></td><td><select id="vtor_a_1" class="inputbox1"></select></td><td><select id="vtor_b_1" class="inputbox1"></select></td><td><select id="vtor_c_1" class="inputbox1"></select></td></tr><tr><td onclick="addrow2(\'a0' + (rowCount-2) + '\');" class="tdbutton">добавить<br />отпайку</td><td colspan="6"></td></tr></table></td>';
//		notab = document.getElementById('a0' + (rowCount-3));
//		notab.rows[notab.rows.length-1].innerHTML = '<td onclick="addrow2();" class="tdbutton_">добавить<br> отпайку</td><td colspan="6"></td>'
		vyvy();
  //alert('#vtor_v_'+(obm.length));
  $('#vtor_v_'+(obm.length)).change(function(){	
	v_1 = this.options[this.selectedIndex].text; 
	seldata = '<option value="">...</option>';
    $.ajax({
      type: "POST",
      url: "/wp-content/themes/semicolon/res2sel.php",
      //data: "table="+ encodeURIComponent("analogs") + '&column0='+ encodeURIComponent("*") + '&case='+ encodeURIComponent("zavodeq'СЭЩ'"),
      data: "table=nagruz&column0=nagr&case=vtor_t_eq_"+v_1,
      success: function(data20){
        $("#d_vtor_a_"+(obm.length)).html(seldata+data20);
      }
    });
  return false;
  });	
	}
	function addrow2(t){
	  if (rowinner1 == '') {rowinner1 = document.getElementById("a00").rows[2].innerHTML;}
	  if (!perekl) {otp = true; $('#perek').prop('disabled', true);}
	  tab = document.getElementById(t);
	  if (tab && !perekl) {
		var rowCount = tab.rows.length;
		rowinner0 = tab.rows[rowCount-2].innerHTML;
		var row = tab.insertRow(rowCount-2);
		t = t.substr(2,1)*1;
	    //if (rowinner1 != '') {rowinner1 = document.getElementById("a0"+t).rows[2].innerHTML;}
		vyv++;
		rowinner0 = rowinner0.replace('<p></p></td>', '<p>' + (rowCount-1) + '</p></td>');
        rowinner0 = rowinner0.replace('_0" class="inputbox"', '_' + (rowCount-1) + '" class="inputbox"');
		rowinner0 = rowinner0.replace('id="td_'+(t)+'"',        'id="td_'+(t)+'_'        + (rowCount-1) + '"');
		rowinner0 = rowinner0.replace('id="vtor_p_'+(t)+'"',    'id="vtor_p_'+(t)+'_'    + (rowCount-1) + '"');
		rowinner0 = rowinner0.replace('id="vtor_v_'+(t)+'"',    'id="vtor_v_'+(t)+'_'    + (rowCount-1) + '"');
		rowinner0 = rowinner0.replace('id="id_vtor_a_'+(t)+'"', 'id="id_vtor_a_'+(t)+'_' + (rowCount-1) + '"');
		rowinner0 = rowinner0.replace('id="d_vtor_a_'+(t)+'"',  'id="d_vtor_a_'+(t)+'_'  + (rowCount-1) + '"');
		rowinner0 = rowinner0.replace('id="vtor_b_'+(t)+'"',    'id="vtor_b_'+(t)+'_'    + (rowCount-1) + '"');
		rowinner0 = rowinner0.replace('id="id_vtor_c_'+(t)+'"', 'id="id_vtor_c_'+(t)+'_' + (rowCount-1) + '"');
		rowinner0 = rowinner0.replace('id="d_vtor_c_'+(t)+'"',  'id="d_vtor_c_'+(t)+'_'  + (rowCount-1) + '"');
		row.innerHTML = rowinner0;
		if ( t > 0 ){ obm[t-1]++; }
		di = document.getElementById("vtor_p_"+t);
		if (di.options[di.selectedIndex]){
		  d = di.options[di.selectedIndex].text;
		  dp = document.getElementById("vtor_p_"+t+"_"+(rowCount-1));
		  for(i=0;i<dp.options.length;i++){
			if (dp.options[i].text == d){dp.selectedIndex = i-1;}
		  }
		}
		di = document.getElementById("vtor_v_"+t);
		if (di.options[di.selectedIndex]){
		  d = di.options[di.selectedIndex].text;
		  dp = document.getElementById("vtor_v_"+t+"_"+(rowCount-1));
		  for(i=0;i<dp.options.length;i++){
			if (dp.options[i].text == d){dp.selectedIndex = i;}
		  }
		  //dp.disabled = true;
		  dp.style.visibility = 'hidden';	
		}
		di = document.getElementById("id_vtor_a_"+t);
		d = di.value;
		dp = document.getElementById("id_vtor_a_"+t+"_"+(rowCount-1));
		dp.value = d;
		di = document.getElementById("vtor_b_"+t);
		if (di.options[di.selectedIndex]){
		  d = di.options[di.selectedIndex].text;
		  dp = document.getElementById("vtor_b_"+t+"_"+(rowCount-1));
		  for(i=0;i<dp.options.length;i++){
			if (dp.options[i].text == d){dp.selectedIndex = i;}
		  }
		}
		di = document.getElementById("id_vtor_c_"+t);
		d = di.value;
		dp = document.getElementById("id_vtor_c_"+t+"_"+(rowCount-1));
		dp.value = d;
		vyvy();
  $('#vtor_v_'+(t)+'_' + (rowCount-1)).change(function(){	
	v_1 = this.options[this.selectedIndex].text; 
	seldata = '<option value="">...</option>';
    $.ajax({
      type: "POST",
      url: "/wp-content/themes/semicolon/res2sel.php",
      //data: "table="+ encodeURIComponent("analogs") + '&column0='+ encodeURIComponent("*") + '&case='+ encodeURIComponent("zavodeq'СЭЩ'"),
      data: "table=nagruz&column0=nagr&case=vtor_t_eq_"+v_1,
      success: function(data20){
        $("#d_vtor_a_"+(t)+"_" + (rowCount-1)).html(seldata+data20);
      }
    });
  return false;
  });	
	  }
	}
	function vyvy(){
		otp = false;
		for (a = 1; a <= obm.length; a++ ){

			  if (obm[a-1] > 0) {
				//document.getElementById('vyv_'+a+'_0').value = (a*2-1)+'И'+(a*2-1)+'-'+(a*2-1)+'И'+(a*2+obm[a-1]);
				otp = true;
				for (b = 0; b <= obm[a-1]; b++){
					//alert('vyv_'+a+'_'+b);
					d = document.getElementById('vyv_'+a+'_'+b);
					//alert('step='+b+' vyv_'+a+'_'+b+'='+d);  alert(this.parentElement.parentElement.parentElement.id); 
					if (document.getElementById('td_'+a+'_'+(b+1))){
						td = document.getElementById('td_'+a+'_'+(b+1));
						if (a < obm.length){td.innerHTML = '<p>'+(b+1)+'</p><div id="udp_'+a+'_'+(b+1)+'" onclick = "obm[this.parentElement.parentElement.parentElement.parentElement.id.substr(2,1)*1-1]--; this.parentElement.parentElement.parentElement.removeChild(this.parentElement.parentElement); vyvy();" class="tddel">Удалить<br>отпайку</div>';}
						//alert('td_'+a+'_'+(b+1)+' - '+td);
						if (a == obm.length){td.innerHTML = '<p>'+(b+1)+'</p><div id="udp_'+a+'_'+(b+1)+'" onclick = "obm[this.parentElement.parentElement.parentElement.parentElement.id.substr(2,1)*1-1]--; this.parentElement.parentElement.parentElement.removeChild(this.parentElement.parentElement); vyvy();" class="tddel">Удалить<br>отпайку</div>';}
					}
					na = '';
					if (obm.length>1) {na = a;}
					if (b==0)
						//d.value = (a*2-1)+'И'+(a*2-1)+'-'+(a*2-1)+'И'+(a*2-1+b);
						d.value = (na)+'И'+(1)+'-'+(na)+'И'+(obm[a-1]+2);
					else
						d.value = (na)+'И'+(1)+'-'+(na)+'И'+(b+1);
				}

			  }
			  else {
					//alert('obm='+a);
				    na = '';
					if (obm.length>1) {na = a;}
				  if (a == obm.length) {
					  //alert(a);
					  document.getElementById('vyv_'+a+'_0').value = (na)+'И'+(1)+'-'+(na)+'И'+(2);
				  }
			      else {
					  //alert(a);
					  document.getElementById('vyv_'+a+'_0').value = (na)+'И'+(1)+'-'+(na)+'И'+(2);
				  }

			}
					if (document.getElementById('tdd_'+(a-1))){
						tdd = document.getElementById('tdd_'+(a-1));
						if (a <= obm.length){tdd.innerHTML = '<p>'+(a)+'</p>';}
						//alert('td_'+a+'_'+(b+1)+' - '+td);
						if (a == obm.length && a > 1){tdd.innerHTML = '<p>'+(a)+'</p><div id="udo_'+(a-1)+'" onclick = "this.parentElement.parentElement.parentElement.removeChild(this.parentElement.parentElement); obm.splice('+(a-1)+', 1); vyvy();" class="tddel">Удалить<br>обмотку</div>';}
					}
		}
		if ((perek * tokper * 1 == 1) && (!otp)) { $('#perek').prop('disabled', false); }
		else {$('#perek').prop('disabled', true);}
	}	

	function popup(classn,t){
		dv = document.getElementById('msg');
		if (classn !='') {dv.className = classn;}
		else {dv.className = 'info';}
		//alert(dv.style.display);
		dv.style.display = 'block';
		//dv.style.left = '150px';
		dv.innerHTML = '<div>Первичный ток</div><p  onclick="this.parentNode.style.display=\'none\';">x</p>';		
	}

	function popup1(ob,t){
		dv = document.getElementById(ob);
		dv.style.display = 'block';
		dv.style.left = '300px';
		dv.innerHTML = '<div>Ток терм.стойкости</div><p  onclick="this.parentNode.style.display=\'none\';">x</p>';		
	}

function search(){
		c = '';
		v = '';
		i = document.getElementById('sform');
		s = document.getElementById('search');
		s.outerHTML = '<select id="search" size="2" style="width:100%; height:50px"><option>Оборудование указаннного типа не найдено</option></select>';

		//тип
		d = document.getElementById('tip');
		c += (d.selectedIndex>0)?(d.options[d.selectedIndex].text):'';
		c += '-НТЗ';

		//напряжение
		d = document.getElementById('napr');
		c += (d.selectedIndex>-1)?('-'+d.options[d.selectedIndex].text):'';

        //габарит
		d = document.getElementById('gab');
		c += (d.selectedIndex>0)?('-'+d.options[d.selectedIndex].text+''):'';

		// коэф.трпнсформации 100х490
		if (isp == 113) {
			d = document.getElementById('koeftr');
		    c += (d.selectedIndex>0)?('-'+d.options[d.selectedIndex].text + ''):'';
		}

		//климатич.категория
		d = document.getElementById('klim_kat');
		c += (d.selectedIndex>0)?(' '+d.options[d.selectedIndex].text + ''):'';

		//d = document.getElementById('per_n');
		//c += (d.selectedIndex>0)?('U1=' + d.options[d.selectedIndex].text + 'В'):'';
		//без обмотки
		//if (bez != '') {c += ' ('+ bez +')';}
		
		//c += ' '+v;
		
		i.value = c;
		//s.innerHTML = '<option>'+c+'</option>';
	sform = i.value; 
	//seldata = '<option value="">...</option>';
    $.ajax({
      type: "POST",
      url: "/wp-content/themes/semicolon/res2sel.php",
      //data: "table="+ encodeURIComponent("analogs") + '&column0='+ encodeURIComponent("*") + '&case='+ encodeURIComponent("zavodeq'СЭЩ'"),
      data: "table=nomenklatura&column0=id&column1=naimenovanie&case=naimenovanie_lk_"+sform,
      //data: "table=nomenklatura&column0=id&column1=naimenovanie&case=naimenovanie_lk_"+encodeURIComponent(sform)+"",
      success: function(data21){
		//data = "/wp-content/themes/semicolon/res2sel.php?table=nomenklatura&column0=id&column1=naimenovanie&case=naimenovanie_lk_"+sform;  
			org = document.getElementById('org').value;
			objectt = document.getElementById('objectt').value;
			count = document.getElementById('count').value;
		    adednew = false;
		if (data21 == '') {
			sr = document.getElementById('search');
			_sform = 'sform';
			sr.outerHTML = '<table id="search" style="max-width:100%;width:100%;"><tr><td colspan="5">Данная номенклатура не изготавливалась, для заказа необходим расчёт возможности изготовления</td></tr><tr><td width="10%" class="tdsmaltxt">Заказываемая конфигурация:</td><td id="newzakaz">...</td><td width="10%" class="tdsmaltxt">Вы можете добавить примечание:</td><td><input type="text" id="newzakaztxt" class="inputbox1" style="width:450px;" /></td><td width="10%"><div class="tdbuttonbl" onclick="addnew(document.getElementById(_sform));" id="clcknew" style="cursor:pointer; width:100px;margin:0px;height:36px;line-height:34px;">Добавить в заказ</div></td></tr></table>';
			document.getElementById('newzakaz').innerText = document.getElementById('sform').value;
		    document.getElementById('clcknew').innerText = 'Добавить в заказ';
			document.getElementById('clcknew').className = 'tdbuttonbl';
			//$("#search").html('<option>Данная номенклатура не изготавливалась, для заказа необходим расчёт возможности изготовления</option>') <input type="text" class="inputbox1" style="width:250px;"/>
		}
        else {
			$("#search").html(data21);
			sr = document.getElementById('search');
			srtext = '<table id="search" style="max-width:100%;width:100%;"><tr><td colspan="4">Найденная номенклатура:</td></tr><tr><td>№</td><td style="text-align:center;">Конфигурация</td><td>Пояснение</td><td>Добавление</td></tr>';
			for (i = 0 ; i < sr.childNodes.length; i++) {
				if (sr.childNodes[i].nodeType == 1) {
					srtext += '<tr><td>'+(i*1+1)+'<input id="id'+i+'" type="hidden" value="'+sr.childNodes[i].value+'" /></td><td id="srt'+i+'">'+sr.childNodes[i].text+'</td><td></td><td><div onclick="addzakaz('+i+');this.className=tdbuttongn; this.innerText=aded;" style="cursor:pointer; width:100px;margin:0px;height:36px;" class="tdbuttonbl">Добавить в заказ</div></td></tr>';
				}
			}
			srtext += '</table>';
			sr.outerHTML = srtext;
		}
      }
    });

}
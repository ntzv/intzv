<div id="config">
<table class="empty" style="max-width:100%;width:100%;">
	<tr>
		<td colspan="5" style="text-align:center;"><p style="max-width:100%;width:100%;"><b>Общие характеристики</b></p></td>
	</tr>				
			<tr>
				<td style="text-align:right;"><p>Организация-заказчик</p></td><td><input id="org" type="text" style="width:500px; background:#fee; border: 1px solid #f01010;"></td><td><p style="text-align:right;margin-bottom: 0.7em;vertical-align:bottom;">ИНН</p></td><td><input id="inn" type="text" style="width:200px; background:#fee; border: 1px solid #f01010;"></td><td></td>
			</tr>
			<tr>
				<td style="text-align:right;"><p>Объект</p></td><td colspan="4"><input id="objectt" type="text" style="width:500px; border: 1px solid #304090;"></td>
			</tr>
			<tr>
				<td style="text-align:right;"><p>Тип</p></td>
				<td><select id="tip" class="inputbox1">
<option value="">...</option>	
<?php
$_REQUEST['table']='tip_tr';
$_REQUEST['column0']='id';
$_REQUEST['column1']='name';
	
include("res2sel.php");
?>
				</select></td>
				<td style="text-align:right;">Количество</td><td><input id="count" type="text" style="width:50px; border: 1px solid #304090;" onchange="this.value = this.value.replace(',','.'); this.value = 0||isNaN(this.value)?1:(Math.abs(Math.round(this.value*1))/1); this.value = (this.value <= 0)?0:this.value;" value="0"></td><td></td>
	</tr>
</table>	

<div id="tabl">
	
</div>
</div>

<div id="nav">
	
</div>

<script type="text/javascript">
	
  $('#tip').change(function(){	
	tiptabl = this.options[this.selectedIndex].text; 
	tipn = this.options[this.selectedIndex].value;  
	//seldata = '<option value="">...</option>';
	if (tiptabl == 'ТОЛ' || tiptabl == 'ТПЛ' || tiptabl == 'ТШЛ') {
     $.ajax({
       type: "POST",
       url: "/wp-content/themes/semicolon/tol.php",
       data: "tabl="+tipn,
	   dataType: "html",
	   async: false,	 
       success: function(datatol){
         $("#tabl").html("");
         $("#tabl").html(datatol);
       }
     });
	 $.ajax({
    	type: "POST",
    	url: "/wp-content/themes/semicolon/tol.js",
    	dataType: "script",
	    async: false,	 
    	cache: false
	 });	
	}
	if (tiptabl == 'НАЛИ' || tiptabl == 'ЗНОЛ' || tiptabl == 'ЗНОЛП' || tiptabl == 'НОЛ' || tiptabl == 'НОЛП') {
     $.ajax({
       type: "POST",
       url: "/wp-content/themes/semicolon/nali.php",
       data: "tabl="+tipn,
	   dataType: "html",
	   async: false,	 
       success: function(datanal){
         $("#tabl").html("");
         $("#tabl").html(datanal);
       }
     });
	 $.ajax({
    	type: "POST",
    	url: "/wp-content/themes/semicolon/nali.js",
    	dataType: "script",
	    async: false,	 
    	cache: false
	 });	
	}
  
	if (tiptabl == 'ЗНТОЛП' || tiptabl == 'НТОЛП') {
     $.ajax({
       type: "POST",
       url: "/wp-content/themes/semicolon/ntol.php",
       data: "tabl="+tipn,
	   dataType: "html",
	   async: false,	 
       success: function(datantl){
         $("#tabl").html("");
         $("#tabl").html(datantl);
       }
     });
	 $.ajax({
    	type: "POST",
    	url: "/wp-content/themes/semicolon/ntol.js",
    	dataType: "script",
	    async: false,	 
    	cache: false
	 });	
	}

	if (tiptabl == 'ТЗЛК' || tiptabl == 'ТЗЛКР') {
     $.ajax({
       type: "POST",
       url: "/wp-content/themes/semicolon/tzlk.php",
       data: "tabl="+tipn,
	   dataType: "html",
	   async: false,	 
       success: function(datatzl){
         $("#tabl").html("");
         $("#tabl").html(datatzl);
       }
     });
	 $.ajax({
    	type: "POST",
    	url: "/wp-content/themes/semicolon/tzlk.js",
    	dataType: "script",
	    async: false,	 
    	cache: false
	 });	
	}

	if (tiptabl ==  'ОЛС' || tiptabl == 'ОЛСП') {
     $.ajax({
       type: "POST",
       url: "/wp-content/themes/semicolon/toltemp0.php",
       data: "tabl="+tipn,
	   dataType: "html",
	   async: false,	 
       success: function(datatml){
         $("#tabl").html("");
         $("#tabl").html(datatml);
       }
     });
	 $.ajax({
    	type: "POST",
    	url: "/wp-content/themes/semicolon/toltemp0.js",
    	dataType: "script",
	    async: false,	 
    	cache: false
	 });
	}
	
	if (tiptabl ==  '3хЗНОЛ' || tiptabl == '3хЗНОЛП') { 
     $.ajax({
       type: "POST",
       url: "/wp-content/themes/semicolon/txzn.php?sesid='"+sesid+"'",
       data: "tabl="+tipn,
	   dataType: "html",
	   async: false,	 
       success: function(datatml){
         $("#tabl").html("");
         $("#tabl").html(datatml);
       }
     });
	 $.ajax({
    	type: "POST",
    	url: "/wp-content/themes/semicolon/txzn.js",
    	dataType: "script",
	    async: false,	 
    	cache: false
	 });
	}
	
	  
   return false;
  });	
	
$('#nav').html('');
	
</script>
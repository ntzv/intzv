<style type="text/css">
	#collapscat-5{
		display:none !important;
	}
	#primary #main{
		margin-left:0 !important;
	}
</style>

<?php

/*
If you would like to edit this file, copy it to your current theme's directory and edit it there.
Theme My Login will always look in your theme's directory first, before using this default template.
*/
?>
<center>
<div class="tml tml-register" id="theme-my-login<?php $template->the_instance(); ?>">
	<?php $template->the_action_template_message( 'register' ); ?>
	<?php $template->the_errors(); ?>
	<form name="registerform" id="registerform<?php $template->the_instance(); ?>" action="<?php $template->the_action_url( 'register', 'login_post' ); ?>" method="post">
		<?php if ( 'email' != $theme_my_login->get_option( 'login_type' ) ) : ?>
		<p class="tml-user-login-wrap">
			<label for="user_login<?php $template->the_instance(); ?>"><?php _e( 'Имя *', 'theme-my-login' ); ?></label>
			<input type="text" name="user_login" id="user_login<?php $template->the_instance(); ?>" class="input" value="<?php $template->the_posted_value( 'user_login' ); ?>" size="20" />
		</p>
		<?php endif; ?>

		<p class="tml-user-email-wrap">
			<label for="user_email<?php $template->the_instance(); ?>"><?php _e( 'E-mail *', 'theme-my-login' ); ?></label>
			<input type="text" name="user_email" id="user_email<?php $template->the_instance(); ?>" class="input" value="<?php $template->the_posted_value( 'user_email' ); ?>" size="20" />
		</p>

<p>
	<label for="org_name<?php $template->the_instance(); ?>"><?php _e( 'Организация *', 'theme-my-login' ) ?></label>
	<input type="text" name="org_name" id="org_name<?php $template->the_instance(); ?>" class="input" value="<?php $template->the_posted_value( 'org_name' ); ?>" size="20" tabindex="20" />
</p>
<p>
	<label for="inn_name<?php $template->the_instance(); ?>"><?php _e( 'ИНН *', 'theme-my-login' ) ?></label>
	<input type="text" name="inn_name" id="inn_name<?php $template->the_instance(); ?>" class="input" value="<?php $template->the_posted_value( 'inn_name' ); ?>" size="20" tabindex="20" />
</p>
		<p>
	<label for="city_name<?php $template->the_instance(); ?>"><?php _e( 'Область,город *', 'theme-my-login' ) ?></label>
	<input type="text" name="city_name" id="city_name<?php $template->the_instance(); ?>" class="input" value="<?php $template->the_posted_value( 'city_name' ); ?>" size="20" tabindex="20" />
</p>
			<p>
	<label for="post_name<?php $template->the_instance(); ?>"><?php _e( 'Почтовый адрес', 'theme-my-login' ) ?></label>
	<input type="text" name="post_name" id="post_name<?php $template->the_instance(); ?>" class="input" value="<?php $template->the_posted_value( 'post_name' ); ?>" size="20" tabindex="20" />
</p>
					<p>
	<label for="face_name<?php $template->the_instance(); ?>"><?php _e( 'Контактное лицо *', 'theme-my-login' ) ?></label>
	<input type="text" name="face_name" id="face_name<?php $template->the_instance(); ?>" class="input" value="<?php $template->the_posted_value( 'face_name' ); ?>" size="20" tabindex="20" />
</p>
<p>
	<label for="phone_name<?php $template->the_instance(); ?>"><?php _e( 'Тел/факс *', 'theme-my-login' ) ?></label>
	<input type="text" name="phone_name" id="phone_name<?php $template->the_instance(); ?>" class="input" value="<?php $template->the_posted_value( 'phone_name' ); ?>" size="20" tabindex="20" />
</p>			
	<p>
	<label for="hobby_name<?php $template->the_instance(); ?>"><?php _e( 'Вид деятельности *', 'theme-my-login' ) ?></label>
	<select name="spisok" size=1>
        <option value="0" selected></option>
        <option value="Дилеры">Дилеры</option>
        <option value="Дистрибьюторы">Дистрибьюторы</option>
        <option value="Инфраструктура">Инфраструктура</option>
        <option value="Проектные институты">Проектные институты</option>
		<option value="Промышленные предприятия">Промышленные предприятия</option>
		<option value="Розничные магазины">Розничные магазины</option>
		<option value="Сети">Сети</option>
		<option value="Строительно-монтажные организации">Строительно-монтажные организации</option>
		<option value="Щитовики">Щитовики</option>
		<option value="Другое">Другое</option>

    <?php $template->the_instance(); ?>" class="input" value="<?php $template->the_posted_value( 'hobby_name' ); ?>" size="20" tabindex="20"     </select>
</p>
<p>
	<label for="shop_name<?php $template->the_instance(); ?>"><?php _e( 'Приобретали ли вы продукцию НТЗ Волхов?', 'theme-my-login' ) ?></label>
	<select name="spisok" size=1>
        <option value="0" selected></option>
        <option value="Да">Да</option>
        <option value="Нет">Нет</option>
    <?php $template->the_instance(); ?>" class="input" value="<?php $template->the_posted_value( 'shop_name' ); ?>" size="20" tabindex="20"     </select>
</p>			
	<p>
	<label for="kind_name<?php $template->the_instance(); ?>"><?php _e( 'Какая продукция Вас интересует  ', 'theme-my-login' ) ?></label>
	<input type="checkbox" name="kind_name" id="kind_name<?php $template->the_instance(); ?>" class="input" value="<?php $template->the_posted_value( 'kind_name' ); ?>" size="20" tabindex="20" />
		<span value="Трансформаторы тока опорные">Трансформаторы тока опорные</span>
		<label>
  <input type="checkbox" name="den" value="Трансформаторы тока проходные" id="CheckboxGroup1_0" />
  Трансформаторы тока проходные</label>
<label>
   <input type="checkbox" name="den" value="Трансформаторы шинные" id="CheckboxGroup1_1" />Трансформаторы шинные
</label>
<label>
  <input type="checkbox" name="den" value="Трансформаторы тока нулевой последовательности" id="CheckboxGroup1_2" />
 Трансформаторы тока нулевой последовательности</label>

		<label>
  <input type="checkbox" name="den" value="Комбинированные трансформаторы" id="CheckboxGroup1_2" />
 Комбинированные трансформаторы</label>
		<label>
  <input type="checkbox" name="den" value="Трансформаторы силовые" id="CheckboxGroup1_2" />
  Трансформаторы силовые</label>
		<label>
  <input type="checkbox" name="den" value="Изоляторы" id="CheckboxGroup1_2" />
  Изоляторы</label>
				<label>
  <input type="checkbox" name="den" value="Трансформаторы напряжения" id="CheckboxGroup1_2" />
 Трансформаторы напряжения</label>
</p>	

		<?php do_action( 'register_form' ); ?>

		<p class="tml-registration-confirmation" id="reg_passmail<?php $template->the_instance(); ?>"><?php echo apply_filters( 'tml_register_passmail_template_message', __( 'Registration confirmation will be e-mailed to you.', 'theme-my-login' ) ); ?></p>

		<p class="tml-submit-wrap">
			<input type="submit" name="wp-submit" id="wp-submit<?php $template->the_instance(); ?>" value="<?php esc_attr_e( 'Register', 'theme-my-login' ); ?>" />
			<input type="hidden" name="redirect_to" value="<?php $template->the_redirect_url( 'register' ); ?>" />
			<input type="hidden" name="instance" value="<?php $template->the_instance(); ?>" />
			<input type="hidden" name="action" value="register" />
		</p>
	</form>
	<?php $template->the_action_links( array( 'register' => false ) ); ?>
</div>
</center>
<?php

//connection parameters
define("DBSERV", "localhost");
define("DBUSER", "9037922491");
define("DBPASS", "kC8K3thy");
define("DBNAME", "9037922491_ntzv");

//used tables
define("ANALOGS", "analogs");
define("ZAVOD", "zavod");
//define("ZAVODY", "gb_ntzv.zavody");
//define("ZAVODY", "gb_ntzv.zavody");

?>